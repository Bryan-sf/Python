from urllib.parse import urlparse

def extrair_titulo_url():
    link = str(input('Cole a URL do site desejado: \n'))

    url = urlparse(link)
    #função do python pra url de sites

    titulo = url.path.strip('/')

    print('O nome do perfil é: ')   
    return titulo 

     