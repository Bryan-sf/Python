import requests
from bs4 import BeautifulSoup
#importa as bibliotecas do beautifulsoup que é a raspagem de dados

def acessar_site():#funcao pra requisicao e entrar no site a partir do beautifulsoup
    link = str(input('Cole a URL do site desejado: \n'))

    requisicao = requests.get(link)
    #acessa o link escolhido pelo usuario

    site = BeautifulSoup(requisicao.text, 'html.parser')
    #printa o "200", se true em 200, esta certo, ja imprime o conteudo em html
    print(requisicao.status_code)

    print('| ' + site.title.text.upper() + ' |' '\nÉ o nome da pagina.')


    """
    seguidores = site.find_all('span')
    print(seguidores[1])
    """
            
    return site
