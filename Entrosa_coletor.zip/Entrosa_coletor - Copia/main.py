#codigo main. Mais organizado e simples para que nao fique tanta coisa visualmente no codigo

from menu import menu_

menu_()

#incompleto