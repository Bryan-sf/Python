from html_coletor import acessar_site
from Url_s import extrair_titulo_url

def menu_():
    while True:
        try:
            resposta = int(input('O que deseja coletar?\n1- Paginas da Web.\n2- Perfis do instagram.\n'))
        except ValueError:
            print('Digite um numero valido.')
            continue

        if resposta == 1:
            site = acessar_site()
            print('\n')
        elif resposta == 2:
            titulo = extrair_titulo_url()
            print(titulo)
            print('\n')
        elif resposta == 0:
            break
        else:
            print('Opcao invalida, tente novamente.')
        
        

